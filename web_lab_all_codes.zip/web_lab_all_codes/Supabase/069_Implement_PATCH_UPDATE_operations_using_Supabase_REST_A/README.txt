Experiment 69
Question: Implement PATCH/UPDATE operations using Supabase REST API.
Category: REST_API
