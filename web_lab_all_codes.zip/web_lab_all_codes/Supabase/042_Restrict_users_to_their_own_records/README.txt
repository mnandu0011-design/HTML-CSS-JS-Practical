Experiment 42
Question: Restrict users to their own records.
Category: Security
