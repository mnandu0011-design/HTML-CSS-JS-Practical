const { data, error } = await supabase.auth.signInWithPassword({
  email: 'student@example.com',
  password: 'Password123'
});
console.log(data, error);