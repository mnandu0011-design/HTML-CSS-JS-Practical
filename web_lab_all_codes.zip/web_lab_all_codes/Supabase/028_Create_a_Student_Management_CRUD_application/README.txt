Experiment 28
Question: Create a Student Management CRUD application.
Category: CRUD
