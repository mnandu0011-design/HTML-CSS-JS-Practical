Experiment 55
Question: Listen for database INSERT events.
Category: Realtime
