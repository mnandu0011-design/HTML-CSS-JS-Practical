Experiment 36
Question: Implement email/password authentication.
Category: Authentication
