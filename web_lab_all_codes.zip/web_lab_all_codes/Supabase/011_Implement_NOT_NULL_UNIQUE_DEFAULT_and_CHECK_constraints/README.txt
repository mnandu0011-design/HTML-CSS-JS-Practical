Experiment 11
Question: Implement NOT NULL, UNIQUE, DEFAULT, and CHECK constraints.
Category: Database_Tables
