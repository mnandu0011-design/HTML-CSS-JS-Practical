Experiment 37
Question: Implement password reset.
Category: Authentication
