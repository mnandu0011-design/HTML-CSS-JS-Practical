Experiment 57
Question: Listen for database DELETE events.
Category: Realtime
