Experiment 4
Question: Create and manage a PostgreSQL database using Supabase.
Category: Supabase_Fundamentals
