Experiment 5
Question: Demonstrate Supabase Table Editor.
Category: Supabase_Fundamentals
