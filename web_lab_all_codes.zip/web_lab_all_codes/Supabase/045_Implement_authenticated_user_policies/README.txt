Experiment 45
Question: Implement authenticated-user policies.
Category: Security
