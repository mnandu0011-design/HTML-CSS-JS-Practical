const { data, error } = await supabase.auth.signUp({
  email: 'student@example.com',
  password: 'Password123'
});
console.log(data, error);