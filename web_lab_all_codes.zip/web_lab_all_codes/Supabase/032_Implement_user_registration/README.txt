Experiment 32
Question: Implement user registration.
Category: Authentication
