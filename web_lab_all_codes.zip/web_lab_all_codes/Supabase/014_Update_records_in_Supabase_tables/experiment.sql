const { data, error } = await supabase
  .from('students')
  .update({ marks:90 })
  .eq('id',1)
  .select();
console.log(data, error);