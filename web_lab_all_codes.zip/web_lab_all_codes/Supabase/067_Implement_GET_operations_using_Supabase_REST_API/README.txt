Experiment 67
Question: Implement GET operations using Supabase REST API.
Category: REST_API
