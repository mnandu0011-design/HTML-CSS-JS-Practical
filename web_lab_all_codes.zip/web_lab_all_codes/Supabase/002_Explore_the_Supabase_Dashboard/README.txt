Experiment 2
Question: Explore the Supabase Dashboard.
Use the Supabase Dashboard for this setup task.
