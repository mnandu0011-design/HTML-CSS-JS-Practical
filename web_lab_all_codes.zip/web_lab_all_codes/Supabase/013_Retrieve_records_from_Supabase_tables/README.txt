Experiment 13
Question: Retrieve records from Supabase tables.
Category: Database_Tables
