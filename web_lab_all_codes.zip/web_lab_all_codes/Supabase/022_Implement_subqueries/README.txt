Experiment 22
Question: Implement subqueries.
Category: SQL_Operations
