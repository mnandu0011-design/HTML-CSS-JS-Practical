Experiment 21
Question: Implement SQL joins.
Category: SQL_Operations
