Experiment 10
Question: Implement primary keys and foreign keys.
Category: Database_Tables
