Experiment 70
Question: Implement DELETE operations using Supabase REST API.
Category: REST_API
