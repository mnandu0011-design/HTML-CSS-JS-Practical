Experiment 59
Question: Create a realtime student record application.
Category: Realtime
