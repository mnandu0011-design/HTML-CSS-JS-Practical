import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  'https://YOUR_PROJECT.supabase.co',
  'YOUR_ANON_KEY'
);

async function run() {
  const { data, error } = await supabase.from('students').select('*');
  if (error) console.error(error);
  else console.log(data);
}
run();
