Experiment 3
Question: Configure project settings and API keys.
Category: Supabase_Fundamentals
