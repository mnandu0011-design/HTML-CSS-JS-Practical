Experiment 54
Question: Enable Supabase Realtime.
Category: Realtime
