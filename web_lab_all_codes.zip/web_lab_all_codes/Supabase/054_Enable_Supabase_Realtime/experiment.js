const channel = supabase
  .channel('students-realtime')
  .on('postgres_changes',
      { event:'*', schema:'public', table:'students' },
      payload => console.log('Change:', payload))
  .subscribe();