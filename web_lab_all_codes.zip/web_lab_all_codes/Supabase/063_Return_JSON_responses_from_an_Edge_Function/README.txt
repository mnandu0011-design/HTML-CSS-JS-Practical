Experiment 63
Question: Return JSON responses from an Edge Function.
Category: Edge_Functions
