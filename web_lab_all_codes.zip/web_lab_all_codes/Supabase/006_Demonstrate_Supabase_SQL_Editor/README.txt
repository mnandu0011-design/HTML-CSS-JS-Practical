Experiment 6
Question: Demonstrate Supabase SQL Editor.
Category: Supabase_Fundamentals
