Experiment 72
Question: Test Supabase REST APIs using Postman.
Category: REST_API
