Experiment 19
Question: Implement GROUP BY and HAVING.
Category: SQL_Operations
