const { error } = await supabase.auth.signOut();
console.log(error);