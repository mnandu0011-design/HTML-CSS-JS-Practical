Experiment 34
Question: Implement user logout.
Category: Authentication
