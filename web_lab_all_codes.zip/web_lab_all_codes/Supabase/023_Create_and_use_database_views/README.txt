Experiment 23
Question: Create and use database views.
Category: SQL_Operations
