Experiment 24
Question: Implement Create operations using Supabase Client.
Category: CRUD
