const { data, error } = await supabase
  .from('students')
  .delete()
  .eq('id',1);
console.log(data, error);