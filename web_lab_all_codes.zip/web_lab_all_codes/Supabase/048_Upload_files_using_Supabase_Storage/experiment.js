const file = document.querySelector('#file')?.files?.[0];
const { data, error } = await supabase.storage
  .from('files')
  .upload(`uploads/${file?.name}`, file, { upsert:true });
console.log(data, error);