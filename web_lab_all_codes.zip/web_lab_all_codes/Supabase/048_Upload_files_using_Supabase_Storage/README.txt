Experiment 48
Question: Upload files using Supabase Storage.
Category: Storage
