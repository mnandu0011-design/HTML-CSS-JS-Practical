Experiment 43
Question: Create Admin and User roles.
Category: Security
