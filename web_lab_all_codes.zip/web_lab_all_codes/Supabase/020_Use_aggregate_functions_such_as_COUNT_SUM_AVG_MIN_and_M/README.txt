Experiment 20
Question: Use aggregate functions such as COUNT, SUM, AVG, MIN, and MAX.
Category: SQL_Operations
