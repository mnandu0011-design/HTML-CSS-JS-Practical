Experiment 17
Question: Implement filtering using WHERE.
Category: SQL_Operations
