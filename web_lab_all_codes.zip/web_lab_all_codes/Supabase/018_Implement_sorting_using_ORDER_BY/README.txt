Experiment 18
Question: Implement sorting using ORDER BY.
Category: SQL_Operations
