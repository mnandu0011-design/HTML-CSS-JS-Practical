Experiment 46
Question: Test database access with different users.
Category: Security
