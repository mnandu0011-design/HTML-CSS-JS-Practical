Experiment 76
Question: Create a Realtime Chat Application using Supabase.
Category: Projects
