Experiment 1
Question: Create a Supabase project.
Use the Supabase Dashboard for this setup task.
