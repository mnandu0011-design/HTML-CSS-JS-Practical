Experiment 35
Question: Retrieve the currently authenticated user.
Category: Authentication
