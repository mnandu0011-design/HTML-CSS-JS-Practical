Experiment 30
Question: Create a User Management CRUD application.
Category: CRUD
