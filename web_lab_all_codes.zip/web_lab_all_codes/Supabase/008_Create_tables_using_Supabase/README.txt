Experiment 8
Question: Create tables using Supabase.
Category: Database_Tables
