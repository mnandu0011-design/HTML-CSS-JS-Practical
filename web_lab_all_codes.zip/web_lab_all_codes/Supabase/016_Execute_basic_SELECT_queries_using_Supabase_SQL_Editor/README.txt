Experiment 16
Question: Execute basic SELECT queries using Supabase SQL Editor.
Category: SQL_Operations
