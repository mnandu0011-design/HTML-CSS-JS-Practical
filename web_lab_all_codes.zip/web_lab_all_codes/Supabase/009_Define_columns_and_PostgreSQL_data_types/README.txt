Experiment 9
Question: Define columns and PostgreSQL data types.
Category: Database_Tables
