Experiment 51
Question: Delete files from Storage.
Category: Storage
