Experiment 62
Question: Pass data to an Edge Function.
Category: Edge_Functions
