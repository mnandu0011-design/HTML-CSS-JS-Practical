-- Run this part in Supabase SQL Editor
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can read their own records"
ON students FOR SELECT
USING (auth.uid() = user_id);