Experiment 40
Question: Enable Row Level Security (RLS).
Category: Security
