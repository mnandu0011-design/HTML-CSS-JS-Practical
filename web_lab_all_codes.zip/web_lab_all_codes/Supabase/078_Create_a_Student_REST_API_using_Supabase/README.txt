Experiment 78
Question: Create a Student REST API using Supabase.
Category: Projects
