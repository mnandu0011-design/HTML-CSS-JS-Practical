Experiment 56
Question: Listen for database UPDATE events.
Category: Realtime
