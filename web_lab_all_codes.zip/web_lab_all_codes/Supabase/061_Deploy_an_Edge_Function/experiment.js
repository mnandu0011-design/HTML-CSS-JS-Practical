// supabase/functions/hello/index.ts
Deno.serve(async (req) => {
  const body = await req.json().catch(() => ({}));
  return new Response(
    JSON.stringify({ message:'Hello from Edge Function', body }),
    { headers:{'Content-Type':'application/json'} }
  );
});