Experiment 61
Question: Deploy an Edge Function.
Category: Edge_Functions
