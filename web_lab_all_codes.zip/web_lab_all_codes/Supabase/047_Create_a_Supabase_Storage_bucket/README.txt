Experiment 47
Question: Create a Supabase Storage bucket.
Category: Storage
