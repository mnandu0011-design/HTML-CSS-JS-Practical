Experiment 44
Question: Implement role-based access control.
Category: Security
