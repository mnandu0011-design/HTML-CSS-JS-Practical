Experiment 66
Question: Access Supabase tables through the generated REST API.
Category: REST_API
