fetch('https://YOUR_PROJECT.supabase.co/rest/v1/students?select=*', {
  headers: {
    apikey: 'YOUR_ANON_KEY',
    Authorization: 'Bearer YOUR_ANON_KEY'
  }
}).then(r=>r.json()).then(console.log);