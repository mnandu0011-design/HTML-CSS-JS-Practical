Experiment 27
Question: Implement Delete operations using Supabase Client.
Category: CRUD
