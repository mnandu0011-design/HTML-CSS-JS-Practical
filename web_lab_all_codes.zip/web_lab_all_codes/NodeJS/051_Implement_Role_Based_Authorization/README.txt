Experiment 51
Question: Implement Role-Based Authorization.
Category: General
