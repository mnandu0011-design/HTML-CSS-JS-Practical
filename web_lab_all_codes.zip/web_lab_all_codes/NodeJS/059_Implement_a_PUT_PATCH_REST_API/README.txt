Experiment 59
Question: Implement a PUT/PATCH REST API.
Category: General
