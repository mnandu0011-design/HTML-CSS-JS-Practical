Experiment 5
Question: Create a Node.js application using built-in modules.
Category: General
