Experiment 13
Question: Handle GET and POST requests using Express.
Category: General
