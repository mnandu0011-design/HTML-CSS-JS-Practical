Experiment 8
Question: Create and use custom Node.js modules.
Category: General
