Experiment 64
Question: Test REST APIs using Postman.
Category: General
