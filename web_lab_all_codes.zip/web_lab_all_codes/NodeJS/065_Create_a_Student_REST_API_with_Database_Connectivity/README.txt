Experiment 65
Question: Create a Student REST API with Database Connectivity.
Category: General
