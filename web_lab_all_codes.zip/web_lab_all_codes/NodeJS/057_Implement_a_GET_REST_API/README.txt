Experiment 57
Question: Implement a GET REST API.
Category: General
