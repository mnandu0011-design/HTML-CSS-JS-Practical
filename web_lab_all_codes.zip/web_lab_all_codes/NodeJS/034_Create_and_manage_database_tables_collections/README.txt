Experiment 34
Question: Create and manage database tables/collections.
Category: General
