// Implement proper HTTP Status Codes in REST APIs.
const express = require('express');
const app = express();
app.use(express.json());

app.get('/', (req,res) => res.json({message:'NodeJS Experiment 61'}));

app.get('/api/students', (req,res) => {
  res.json([{id:1,name:'Shiva',department:'CSE'},{id:2,name:'Ravi',department:'ECE'}]);
});

app.post('/api/students', (req,res) => {
  res.status(201).json({message:'Created', data:req.body});
});

app.put('/api/students/:id', (req,res) => {
  res.json({message:'Updated', id:req.params.id, data:req.body});
});

app.delete('/api/students/:id', (req,res) => {
  res.json({message:'Deleted', id:req.params.id});
});

app.use((req,res) => res.status(404).json({error:'Not Found'}));

app.listen(3000, () => console.log('Server running at http://localhost:3000'));
