Experiment 61
Question: Implement proper HTTP Status Codes in REST APIs.
Category: General
