const bcrypt=require('bcryptjs');
(async()=>{
 const hash=await bcrypt.hash('MyPassword123',10);
 console.log(hash);
 console.log(await bcrypt.compare('MyPassword123',hash));
})();