Experiment 14
Question: Serve static files using Express.
Category: General
