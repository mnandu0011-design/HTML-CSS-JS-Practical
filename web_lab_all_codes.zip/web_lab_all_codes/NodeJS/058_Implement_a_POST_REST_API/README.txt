Experiment 58
Question: Implement a POST REST API.
Category: General
