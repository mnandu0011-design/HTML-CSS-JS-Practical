Experiment 27
Question: Demonstrate the execution order of middleware.
Category: General
