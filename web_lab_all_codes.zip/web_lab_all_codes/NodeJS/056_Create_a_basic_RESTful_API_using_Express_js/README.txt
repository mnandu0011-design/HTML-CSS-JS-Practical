Experiment 56
Question: Create a basic RESTful API using Express.js.
Category: General
