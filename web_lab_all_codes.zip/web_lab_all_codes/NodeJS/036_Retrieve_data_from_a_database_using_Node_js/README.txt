Experiment 36
Question: Retrieve data from a database using Node.js.
Category: General
