Experiment 10
Question: Demonstrate Callbacks, Promises, and Async/Await in Node.js.
Category: General
