Experiment 26
Question: Implement error-handling middleware.
Category: General
