Experiment 23
Question: Implement logging middleware.
Category: General
