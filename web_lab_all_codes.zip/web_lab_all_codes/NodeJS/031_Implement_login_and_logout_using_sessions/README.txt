Experiment 31
Question: Implement login and logout using sessions.
Category: General
