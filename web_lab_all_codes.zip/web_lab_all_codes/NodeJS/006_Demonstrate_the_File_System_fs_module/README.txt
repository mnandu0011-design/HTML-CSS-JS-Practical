Experiment 6
Question: Demonstrate the File System (fs) module.
Category: General
