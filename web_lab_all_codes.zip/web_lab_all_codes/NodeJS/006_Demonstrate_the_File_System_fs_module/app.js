const fs=require('fs');
fs.writeFileSync('example.txt','Hello Node.js');
console.log(fs.readFileSync('example.txt','utf8'));