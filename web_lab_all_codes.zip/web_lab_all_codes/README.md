# Web Development Lab - All Codes

This package follows the experiment list supplied in the uploaded markdown.

## Folder pattern
- HTML/01_Basic_Webpage/
- CSS/001_.../
- JavaScript/001_.../
- MySQL/001_.../
- NodeJS/001_.../
- Supabase/001_.../

Each experiment has a README.txt containing the original question and one or more runnable source files.

## Running
HTML/CSS/JavaScript: open the `.html` file in a browser (or use VS Code Live Server).
MySQL: open the `.sql` file in MySQL Workbench and run it.
NodeJS: open the experiment folder, run `npm install`, then `node app.js` where applicable.
Supabase: install `@supabase/supabase-js`, replace project URL/key placeholders, and use the supplied SQL/code.

Some advanced experiments necessarily use placeholders for credentials, API keys, or database configuration. Do not commit real secrets.
