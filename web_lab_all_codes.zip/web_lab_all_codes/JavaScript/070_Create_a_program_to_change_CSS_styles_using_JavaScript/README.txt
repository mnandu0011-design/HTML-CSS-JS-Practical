Experiment 70
Question: Create a program to change CSS styles using JavaScript.
Category: General
