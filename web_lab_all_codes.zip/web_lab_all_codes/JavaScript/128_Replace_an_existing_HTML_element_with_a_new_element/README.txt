Experiment 128
Question: Replace an existing HTML element with a new element.
Category: General
