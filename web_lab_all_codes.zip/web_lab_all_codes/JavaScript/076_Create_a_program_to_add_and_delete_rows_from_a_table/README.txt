Experiment 76
Question: Create a program to add and delete rows from a table.
Category: General
