Experiment 252
Question: Compare localStorage and sessionStorage.
Category: General
