Experiment 240
Question: Delete an item from localStorage.
Category: General
