Experiment 126
Question: Create a new HTML element dynamically and add it to the webpage.
Category: General
