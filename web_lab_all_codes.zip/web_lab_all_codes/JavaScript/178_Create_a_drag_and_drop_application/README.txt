Experiment 178
Question: Create a drag-and-drop application.
Category: General
