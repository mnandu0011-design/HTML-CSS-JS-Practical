Experiment 73
Question: Demonstrate querySelector() and querySelectorAll().
Category: General
