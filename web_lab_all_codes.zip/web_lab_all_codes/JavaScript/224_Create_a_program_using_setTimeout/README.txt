Experiment 224
Question: Create a program using setTimeout().
Category: General
