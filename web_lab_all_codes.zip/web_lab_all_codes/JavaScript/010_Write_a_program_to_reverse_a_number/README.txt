Experiment 10
Question: Write a program to reverse a number.
Category: General
