Experiment 220
Question: Create a shopping order form and calculate the total price.
Category: General
