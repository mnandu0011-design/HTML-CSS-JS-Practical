Experiment 105
Question: Create a theme switcher (light/dark mode) using localStorage.
Category: General
