Experiment 4
Question: Write a program to check whether a number is even or odd.
Category: General
