Experiment 71
Question: Create a program to change multiple HTML elements simultaneously.
Category: General
