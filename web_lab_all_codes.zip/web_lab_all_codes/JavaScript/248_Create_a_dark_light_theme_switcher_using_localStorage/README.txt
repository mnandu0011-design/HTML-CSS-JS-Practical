Experiment 248
Question: Create a dark/light theme switcher using localStorage.
Category: General
