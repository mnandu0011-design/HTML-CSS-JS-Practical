Experiment 65
Question: Write a program to find the frequency of characters in a string.
Category: General
