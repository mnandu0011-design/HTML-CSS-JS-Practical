Experiment 187
Question: Validate an age field using JavaScript.
Category: General
