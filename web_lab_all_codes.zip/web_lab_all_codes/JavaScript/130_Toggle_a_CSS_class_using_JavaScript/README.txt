Experiment 130
Question: Toggle a CSS class using JavaScript.
Category: General
