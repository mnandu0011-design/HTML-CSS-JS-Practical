Experiment 217
Question: Create a form that calculates and displays age from date of birth.
Category: General
