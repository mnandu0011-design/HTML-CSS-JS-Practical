Experiment 33
Question: Create a simple quiz application.
Category: General
