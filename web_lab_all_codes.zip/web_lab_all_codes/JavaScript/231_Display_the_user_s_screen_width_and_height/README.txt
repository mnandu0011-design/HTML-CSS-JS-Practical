Experiment 231
Question: Display the user's screen width and height.
Category: General
