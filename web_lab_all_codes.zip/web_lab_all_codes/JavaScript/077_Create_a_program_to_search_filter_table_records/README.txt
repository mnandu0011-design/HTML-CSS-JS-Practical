Experiment 77
Question: Create a program to search/filter table records.
Category: General
