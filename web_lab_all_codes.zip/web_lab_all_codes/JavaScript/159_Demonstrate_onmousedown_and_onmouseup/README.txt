Experiment 159
Question: Demonstrate onmousedown and onmouseup.
Category: General
