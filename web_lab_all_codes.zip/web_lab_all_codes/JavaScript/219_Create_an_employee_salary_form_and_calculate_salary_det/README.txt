Experiment 219
Question: Create an employee salary form and calculate salary details.
Category: General
