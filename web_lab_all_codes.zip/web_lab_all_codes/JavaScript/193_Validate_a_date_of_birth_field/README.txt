Experiment 193
Question: Validate a date of birth field.
Category: General
