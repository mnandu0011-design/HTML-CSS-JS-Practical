Experiment 167
Question: Demonstrate the input event.
Category: General
