Experiment 233
Question: Display the current browser language.
Category: General
