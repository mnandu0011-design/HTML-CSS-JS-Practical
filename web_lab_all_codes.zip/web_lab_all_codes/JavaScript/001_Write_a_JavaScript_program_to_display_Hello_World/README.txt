Experiment 1
Question: Write a JavaScript program to display “Hello World”.
Category: General
