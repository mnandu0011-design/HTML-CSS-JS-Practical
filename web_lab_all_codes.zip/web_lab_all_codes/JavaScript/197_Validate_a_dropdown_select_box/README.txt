Experiment 197
Question: Validate a dropdown/select box.
Category: General
