Experiment 116
Question: Create a simple shopping cart.
Category: General
