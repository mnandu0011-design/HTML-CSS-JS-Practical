Experiment 156
Question: Demonstrate the onclick event.
Category: General
