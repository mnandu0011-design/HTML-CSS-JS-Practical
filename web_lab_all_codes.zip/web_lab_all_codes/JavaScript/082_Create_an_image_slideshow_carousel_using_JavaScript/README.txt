Experiment 82
Question: Create an image slideshow/carousel using JavaScript.
Category: General
