Experiment 165
Question: Demonstrate the focus and blur events.
Category: General
