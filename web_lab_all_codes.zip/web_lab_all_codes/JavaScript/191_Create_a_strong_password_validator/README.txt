Experiment 191
Question: Create a strong password validator.
Category: General
