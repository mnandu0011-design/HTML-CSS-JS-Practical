Experiment 192
Question: Validate password and confirm password fields.
Category: General
