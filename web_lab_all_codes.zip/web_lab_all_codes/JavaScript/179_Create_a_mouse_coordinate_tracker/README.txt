Experiment 179
Question: Create a mouse coordinate tracker.
Category: General
