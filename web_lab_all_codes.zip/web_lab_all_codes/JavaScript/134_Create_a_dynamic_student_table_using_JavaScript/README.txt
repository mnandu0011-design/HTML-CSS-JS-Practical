Experiment 134
Question: Create a dynamic student table using JavaScript.
Category: General
