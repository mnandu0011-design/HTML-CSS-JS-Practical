Experiment 228
Question: Display the current webpage URL using JavaScript.
Category: General
