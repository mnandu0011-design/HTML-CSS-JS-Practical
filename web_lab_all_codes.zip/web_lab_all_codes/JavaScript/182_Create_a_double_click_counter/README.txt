Experiment 182
Question: Create a double-click counter.
Category: General
