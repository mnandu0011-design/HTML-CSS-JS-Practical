Experiment 124
Question: Change the style of an HTML element dynamically.
Category: General
