Experiment 85
Question: Demonstrate form events such as submit, change, focus, and blur.
Category: General
