Experiment 79
Question: Create a password show/hide feature.
Category: General
