Experiment 244
Question: Store a JavaScript object in localStorage.
Category: General
