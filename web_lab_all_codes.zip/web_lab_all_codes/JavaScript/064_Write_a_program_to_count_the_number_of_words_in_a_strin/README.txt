Experiment 64
Question: Write a program to count the number of words in a string.
Category: General
