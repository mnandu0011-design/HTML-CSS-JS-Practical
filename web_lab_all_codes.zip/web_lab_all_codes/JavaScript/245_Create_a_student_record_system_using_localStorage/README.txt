Experiment 245
Question: Create a student record system using localStorage.
Category: General
