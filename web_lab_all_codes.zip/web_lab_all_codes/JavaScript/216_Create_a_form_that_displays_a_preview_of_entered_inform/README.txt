Experiment 216
Question: Create a form that displays a preview of entered information before submission.
Category: General
