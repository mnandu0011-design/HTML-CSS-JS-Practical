Experiment 226
Question: Create a digital clock using setInterval().
Category: General
