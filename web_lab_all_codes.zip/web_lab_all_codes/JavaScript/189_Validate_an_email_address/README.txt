Experiment 189
Question: Validate an email address.
Category: General
