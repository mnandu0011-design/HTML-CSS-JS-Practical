Experiment 40
Question: Demonstrate classes and objects.
Category: General
