Experiment 22
Question: Create a webpage that changes text using JavaScript.
Category: General
