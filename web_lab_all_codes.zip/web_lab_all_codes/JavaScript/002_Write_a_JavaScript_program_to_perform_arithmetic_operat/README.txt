Experiment 2
Question: Write a JavaScript program to perform arithmetic operations.
Category: General
