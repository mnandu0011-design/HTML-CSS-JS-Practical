Experiment 223
Question: Demonstrate alert(), confirm(), and prompt().
Category: General
