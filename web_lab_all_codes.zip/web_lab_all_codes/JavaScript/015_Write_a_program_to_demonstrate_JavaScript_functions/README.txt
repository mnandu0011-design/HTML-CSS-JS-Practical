Experiment 15
Question: Write a program to demonstrate JavaScript functions.
Category: General
