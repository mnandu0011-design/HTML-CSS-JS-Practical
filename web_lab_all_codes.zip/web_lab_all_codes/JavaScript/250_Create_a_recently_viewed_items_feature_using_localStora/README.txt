Experiment 250
Question: Create a recently viewed items feature using localStorage.
Category: General
