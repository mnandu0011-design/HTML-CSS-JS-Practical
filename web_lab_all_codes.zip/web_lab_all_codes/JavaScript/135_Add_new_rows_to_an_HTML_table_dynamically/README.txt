Experiment 135
Question: Add new rows to an HTML table dynamically.
Category: General
