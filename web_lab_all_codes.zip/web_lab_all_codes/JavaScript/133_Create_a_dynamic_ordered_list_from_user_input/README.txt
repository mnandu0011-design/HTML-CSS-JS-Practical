Experiment 133
Question: Create a dynamic ordered list from user input.
Category: General
