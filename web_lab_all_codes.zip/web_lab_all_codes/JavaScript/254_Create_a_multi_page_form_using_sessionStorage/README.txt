Experiment 254
Question: Create a multi-page form using sessionStorage.
Category: General
