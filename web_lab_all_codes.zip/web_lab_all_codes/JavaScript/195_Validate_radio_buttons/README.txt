Experiment 195
Question: Validate radio buttons.
Category: General
