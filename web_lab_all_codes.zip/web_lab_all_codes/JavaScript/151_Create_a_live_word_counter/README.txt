Experiment 151
Question: Create a live word counter.
Category: General
