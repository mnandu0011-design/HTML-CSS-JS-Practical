Experiment 122
Question: Change the text content of an HTML element using JavaScript.
Category: General
