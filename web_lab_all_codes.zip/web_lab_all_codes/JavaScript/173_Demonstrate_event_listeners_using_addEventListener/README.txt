Experiment 173
Question: Demonstrate event listeners using addEventListener().
Category: General
