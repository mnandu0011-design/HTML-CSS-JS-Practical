Experiment 177
Question: Demonstrate event capturing.
Category: General
