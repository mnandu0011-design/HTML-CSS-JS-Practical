Experiment 119
Question: Create a BMI calculator.
Category: General
