Experiment 185
Question: Create a student registration form and validate all fields.
Category: General
