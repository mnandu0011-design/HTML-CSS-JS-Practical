Experiment 131
Question: Change the attributes of an HTML element dynamically.
Category: General
