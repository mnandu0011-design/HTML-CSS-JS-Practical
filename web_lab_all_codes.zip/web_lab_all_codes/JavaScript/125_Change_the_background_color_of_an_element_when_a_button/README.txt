Experiment 125
Question: Change the background color of an element when a button is clicked.
Category: General
