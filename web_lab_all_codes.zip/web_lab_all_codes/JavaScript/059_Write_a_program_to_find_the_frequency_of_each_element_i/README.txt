Experiment 59
Question: Write a program to find the frequency of each element in an array.
Category: General
