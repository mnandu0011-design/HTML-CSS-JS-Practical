Experiment 140
Question: Create a dynamic dropdown menu using JavaScript.
Category: General
