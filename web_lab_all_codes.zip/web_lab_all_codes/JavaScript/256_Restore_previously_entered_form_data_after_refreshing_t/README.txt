Experiment 256
Question: Restore previously entered form data after refreshing the page.
Category: General
