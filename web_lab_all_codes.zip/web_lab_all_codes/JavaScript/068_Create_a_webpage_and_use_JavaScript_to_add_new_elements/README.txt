Experiment 68
Question: Create a webpage and use JavaScript to add new elements dynamically.
Category: General
