Experiment 155
Question: Demonstrate createElement(), appendChild(), remove(), and replaceChild().
Category: General
