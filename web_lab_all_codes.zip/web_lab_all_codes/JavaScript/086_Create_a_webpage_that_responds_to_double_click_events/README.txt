Experiment 86
Question: Create a webpage that responds to double-click events.
Category: General
