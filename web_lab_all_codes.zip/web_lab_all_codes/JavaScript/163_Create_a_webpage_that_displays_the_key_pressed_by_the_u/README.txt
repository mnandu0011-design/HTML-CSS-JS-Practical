Experiment 163
Question: Create a webpage that displays the key pressed by the user.
Category: General
