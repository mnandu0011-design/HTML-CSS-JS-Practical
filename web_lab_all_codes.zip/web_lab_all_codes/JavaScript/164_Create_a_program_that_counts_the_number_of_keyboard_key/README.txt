Experiment 164
Question: Create a program that counts the number of keyboard key presses.
Category: General
