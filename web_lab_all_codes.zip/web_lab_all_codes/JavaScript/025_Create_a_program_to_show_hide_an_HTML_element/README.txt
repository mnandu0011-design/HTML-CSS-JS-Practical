Experiment 25
Question: Create a program to show/hide an HTML element.
Category: General
