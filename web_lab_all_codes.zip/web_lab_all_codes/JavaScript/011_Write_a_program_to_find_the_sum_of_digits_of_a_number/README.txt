Experiment 11
Question: Write a program to find the sum of digits of a number.
Category: General
