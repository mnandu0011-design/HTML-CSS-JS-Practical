Experiment 78
Question: Create a live character counter for a textarea.
Category: General
