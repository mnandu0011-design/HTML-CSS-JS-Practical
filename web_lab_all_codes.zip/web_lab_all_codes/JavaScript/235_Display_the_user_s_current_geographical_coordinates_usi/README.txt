Experiment 235
Question: Display the user's current geographical coordinates using the Geolocation API.
Category: General
