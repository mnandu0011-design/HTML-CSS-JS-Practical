Experiment 108
Question: Create a stopwatch.
Category: General
