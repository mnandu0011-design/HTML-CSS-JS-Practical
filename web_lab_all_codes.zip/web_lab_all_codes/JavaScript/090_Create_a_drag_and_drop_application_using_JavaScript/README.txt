Experiment 90
Question: Create a drag-and-drop application using JavaScript.
Category: General
