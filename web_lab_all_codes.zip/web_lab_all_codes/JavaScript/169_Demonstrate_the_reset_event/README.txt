Experiment 169
Question: Demonstrate the reset event.
Category: General
