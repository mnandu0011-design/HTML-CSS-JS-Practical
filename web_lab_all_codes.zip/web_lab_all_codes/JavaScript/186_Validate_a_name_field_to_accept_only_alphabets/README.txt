Experiment 186
Question: Validate a name field to accept only alphabets.
Category: General
