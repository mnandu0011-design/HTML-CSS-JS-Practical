Experiment 72
Question: Demonstrate getElementById() and getElementsByClassName().
Category: General
