Experiment 62
Question: Write a program to check whether a string is a palindrome.
Category: General
