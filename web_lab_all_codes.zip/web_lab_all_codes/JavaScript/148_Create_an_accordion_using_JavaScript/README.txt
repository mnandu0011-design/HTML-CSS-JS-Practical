Experiment 148
Question: Create an accordion using JavaScript.
Category: General
