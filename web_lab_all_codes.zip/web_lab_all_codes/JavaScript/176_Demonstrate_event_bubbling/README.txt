Experiment 176
Question: Demonstrate event bubbling.
Category: General
