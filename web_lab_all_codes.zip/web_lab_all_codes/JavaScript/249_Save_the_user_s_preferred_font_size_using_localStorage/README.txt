Experiment 249
Question: Save the user's preferred font size using localStorage.
Category: General
