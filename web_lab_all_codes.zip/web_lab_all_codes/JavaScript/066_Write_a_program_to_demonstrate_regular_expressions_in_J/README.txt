Experiment 66
Question: Write a program to demonstrate regular expressions in JavaScript.
Category: General
