Experiment 118
Question: Create a random password generator.
Category: General
