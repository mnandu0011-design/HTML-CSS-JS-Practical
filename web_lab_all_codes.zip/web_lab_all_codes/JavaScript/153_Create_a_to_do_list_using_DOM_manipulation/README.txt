Experiment 153
Question: Create a to-do list using DOM manipulation.
Category: General
