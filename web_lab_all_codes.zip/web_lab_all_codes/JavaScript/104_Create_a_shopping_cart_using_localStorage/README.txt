Experiment 104
Question: Create a shopping cart using localStorage.
Category: General
