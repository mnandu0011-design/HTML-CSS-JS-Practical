Experiment 35
Question: Create a stopwatch using JavaScript.
Category: General
