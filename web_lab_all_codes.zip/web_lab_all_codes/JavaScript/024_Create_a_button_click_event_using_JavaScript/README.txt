Experiment 24
Question: Create a button click event using JavaScript.
Category: General
