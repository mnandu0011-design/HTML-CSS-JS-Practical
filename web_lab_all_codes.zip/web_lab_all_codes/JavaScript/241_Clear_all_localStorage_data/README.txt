Experiment 241
Question: Clear all localStorage data.
Category: General
