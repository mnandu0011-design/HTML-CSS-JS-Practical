Experiment 58
Question: Write a program to merge two arrays.
Category: General
