Experiment 42
Question: Demonstrate callbacks, promises, and async/await.
Category: General
