Experiment 91
Question: Create a student registration form with JavaScript validation.
Category: General
