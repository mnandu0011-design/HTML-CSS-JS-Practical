Experiment 60
Question: Write a program to find common elements in two arrays.
Category: General
