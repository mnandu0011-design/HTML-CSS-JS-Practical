Experiment 210
Question: Create a show/hide password option.
Category: General
