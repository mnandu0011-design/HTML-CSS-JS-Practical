Experiment 208
Question: Validate fields using the input, change, focus, and blur events.
Category: General
