Experiment 190
Question: Validate a password based on minimum length.
Category: General
