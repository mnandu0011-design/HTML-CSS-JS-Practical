Experiment 129
Question: Add and remove CSS classes using JavaScript.
Category: General
