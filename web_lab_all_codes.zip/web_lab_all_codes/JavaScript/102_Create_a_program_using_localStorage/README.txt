Experiment 102
Question: Create a program using localStorage.
Category: General
