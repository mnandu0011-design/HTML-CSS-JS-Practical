Experiment 204
Question: Validate an email using a regular expression.
Category: General
