Experiment 88
Question: Demonstrate event delegation.
Category: General
