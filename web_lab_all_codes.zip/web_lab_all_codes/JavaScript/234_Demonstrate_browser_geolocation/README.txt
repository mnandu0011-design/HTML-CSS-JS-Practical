Experiment 234
Question: Demonstrate browser geolocation.
Category: General
