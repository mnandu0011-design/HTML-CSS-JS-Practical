Experiment 147
Question: Create a tabs interface using DOM manipulation.
Category: General
