Experiment 253
Question: Store temporary form data using sessionStorage.
Category: General
