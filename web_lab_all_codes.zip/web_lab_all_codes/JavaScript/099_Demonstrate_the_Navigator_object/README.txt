Experiment 99
Question: Demonstrate the Navigator object.
Category: General
