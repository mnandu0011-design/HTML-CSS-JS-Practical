Experiment 50
Question: Write a program to find the least common multiple (LCM) of two numbers.
Category: General
