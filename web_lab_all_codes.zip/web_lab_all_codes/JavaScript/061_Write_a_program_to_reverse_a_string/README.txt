Experiment 61
Question: Write a program to reverse a string.
Category: General
