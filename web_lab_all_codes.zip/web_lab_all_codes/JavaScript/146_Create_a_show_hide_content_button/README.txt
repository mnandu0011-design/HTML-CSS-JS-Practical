Experiment 146
Question: Create a show/hide content button.
Category: General
