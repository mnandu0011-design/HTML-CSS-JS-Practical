Experiment 138
Question: Create a searchable/filterable table.
Category: General
