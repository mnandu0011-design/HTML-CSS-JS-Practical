Experiment 49
Question: Write a program to find the greatest common divisor (GCD) of two numbers.
Category: General
