Experiment 12
Question: Write a program to find the largest and smallest element in an array.
Category: General
