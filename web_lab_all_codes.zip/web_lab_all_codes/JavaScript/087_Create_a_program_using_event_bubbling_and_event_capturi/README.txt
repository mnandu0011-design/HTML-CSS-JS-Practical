Experiment 87
Question: Create a program using event bubbling and event capturing.
Category: General
