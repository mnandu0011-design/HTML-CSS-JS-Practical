Experiment 157
Question: Demonstrate the ondblclick event.
Category: General
