Experiment 36
Question: Create a countdown timer using JavaScript.
Category: General
