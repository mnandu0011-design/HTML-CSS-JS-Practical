Experiment 196
Question: Validate checkbox selection.
Category: General
