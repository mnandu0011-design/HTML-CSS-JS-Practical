Experiment 34
Question: Create a counter application with increment and decrement buttons.
Category: General
