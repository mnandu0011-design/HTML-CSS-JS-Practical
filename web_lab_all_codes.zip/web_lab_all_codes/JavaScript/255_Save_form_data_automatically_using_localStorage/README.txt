Experiment 255
Question: Save form data automatically using localStorage.
Category: General
