Experiment 45
Question: Store and retrieve data using localStorage.
Category: General
