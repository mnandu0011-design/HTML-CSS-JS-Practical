Experiment 215
Question: Create a multi-step registration form.
Category: General
