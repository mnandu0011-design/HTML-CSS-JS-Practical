Experiment 38
Question: Demonstrate ES6 let, const, template literals, and destructuring.
Category: General
