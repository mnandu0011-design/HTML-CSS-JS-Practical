Experiment 211
Question: Create a registration form with password confirmation.
Category: General
