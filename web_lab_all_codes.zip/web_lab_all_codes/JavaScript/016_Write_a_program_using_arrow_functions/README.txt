Experiment 16
Question: Write a program using arrow functions.
Category: General
