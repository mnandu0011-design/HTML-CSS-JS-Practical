Experiment 14
Question: Write a program to find the sum and average of array elements.
Category: General
