Experiment 145
Question: Create a show/hide password feature.
Category: General
