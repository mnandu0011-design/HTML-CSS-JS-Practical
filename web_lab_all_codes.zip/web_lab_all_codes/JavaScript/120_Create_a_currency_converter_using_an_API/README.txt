Experiment 120
Question: Create a currency converter using an API.
Category: General
