Experiment 230
Question: Display browser information using JavaScript.
Category: General
