Experiment 20
Question: Write a program demonstrating Date and Math objects.
Category: General
