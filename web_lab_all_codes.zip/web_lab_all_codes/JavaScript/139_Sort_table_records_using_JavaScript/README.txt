Experiment 139
Question: Sort table records using JavaScript.
Category: General
