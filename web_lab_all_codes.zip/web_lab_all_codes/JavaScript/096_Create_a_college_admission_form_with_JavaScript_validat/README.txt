Experiment 96
Question: Create a college admission form with JavaScript validation.
Category: General
