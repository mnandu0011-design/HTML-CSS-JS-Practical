Experiment 83
Question: Demonstrate mouse events using JavaScript.
Category: General
