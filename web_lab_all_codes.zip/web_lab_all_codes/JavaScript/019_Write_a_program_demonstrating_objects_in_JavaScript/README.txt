Experiment 19
Question: Write a program demonstrating objects in JavaScript.
Category: General
