Experiment 181
Question: Create a click counter.
Category: General
