Experiment 172
Question: Create a webpage with multiple buttons having different event handlers.
Category: General
