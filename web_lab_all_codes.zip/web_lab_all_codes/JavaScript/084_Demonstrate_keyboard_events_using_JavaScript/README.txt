Experiment 84
Question: Demonstrate keyboard events using JavaScript.
Category: General
