Experiment 100
Question: Demonstrate the Location object.
Category: General
