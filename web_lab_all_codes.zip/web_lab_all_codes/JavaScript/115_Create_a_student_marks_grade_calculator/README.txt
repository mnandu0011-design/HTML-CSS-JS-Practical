Experiment 115
Question: Create a student marks/grade calculator.
Category: General
