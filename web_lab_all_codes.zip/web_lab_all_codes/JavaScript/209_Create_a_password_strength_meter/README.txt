Experiment 209
Question: Create a password strength meter.
Category: General
