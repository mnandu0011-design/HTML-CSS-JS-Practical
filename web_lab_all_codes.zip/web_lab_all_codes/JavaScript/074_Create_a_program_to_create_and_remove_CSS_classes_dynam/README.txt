Experiment 74
Question: Create a program to create and remove CSS classes dynamically.
Category: General
