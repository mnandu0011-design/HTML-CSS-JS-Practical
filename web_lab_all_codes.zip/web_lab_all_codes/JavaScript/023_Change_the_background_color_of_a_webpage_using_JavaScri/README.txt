Experiment 23
Question: Change the background color of a webpage using JavaScript.
Category: General
