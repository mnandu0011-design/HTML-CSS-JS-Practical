Experiment 170
Question: Create a button that changes the background color when clicked.
Category: General
