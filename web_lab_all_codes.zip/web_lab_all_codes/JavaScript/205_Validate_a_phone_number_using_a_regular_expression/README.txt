Experiment 205
Question: Validate a phone number using a regular expression.
Category: General
