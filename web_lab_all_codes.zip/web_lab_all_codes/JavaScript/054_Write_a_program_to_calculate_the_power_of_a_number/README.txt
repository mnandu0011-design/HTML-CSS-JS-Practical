Experiment 54
Question: Write a program to calculate the power of a number.
Category: General
