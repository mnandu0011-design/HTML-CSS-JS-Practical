Experiment 31
Question: Validate name, email, phone number, and password using JavaScript.
Category: General
