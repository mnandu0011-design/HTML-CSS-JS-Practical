Experiment 75
Question: Create a dynamic table using JavaScript.
Category: General
