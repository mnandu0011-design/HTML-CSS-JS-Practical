Experiment 143
Question: Create an image gallery dynamically from an array of image data.
Category: General
