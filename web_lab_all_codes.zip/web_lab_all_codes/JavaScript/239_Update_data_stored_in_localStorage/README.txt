Experiment 239
Question: Update data stored in localStorage.
Category: General
