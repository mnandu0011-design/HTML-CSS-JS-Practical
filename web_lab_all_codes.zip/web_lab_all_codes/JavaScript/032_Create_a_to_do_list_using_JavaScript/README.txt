Experiment 32
Question: Create a to-do list using JavaScript.
Category: General
