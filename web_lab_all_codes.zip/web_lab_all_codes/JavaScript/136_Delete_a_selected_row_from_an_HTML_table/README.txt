Experiment 136
Question: Delete a selected row from an HTML table.
Category: General
