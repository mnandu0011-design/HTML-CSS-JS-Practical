Experiment 93
Question: Create a password strength checker.
Category: General
