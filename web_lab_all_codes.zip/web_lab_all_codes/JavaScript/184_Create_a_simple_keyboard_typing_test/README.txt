Experiment 184
Question: Create a simple keyboard typing test.
Category: General
