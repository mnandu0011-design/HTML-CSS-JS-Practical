Experiment 180
Question: Create a keyboard-controlled moving object.
Category: General
