Experiment 8
Question: Write a program to check whether a number is prime.
Category: General
