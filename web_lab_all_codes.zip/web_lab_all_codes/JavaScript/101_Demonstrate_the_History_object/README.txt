Experiment 101
Question: Demonstrate the History object.
Category: General
