Experiment 109
Question: Create a countdown timer.
Category: General
