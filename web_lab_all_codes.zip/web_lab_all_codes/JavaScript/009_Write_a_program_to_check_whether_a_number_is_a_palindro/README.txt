Experiment 9
Question: Write a program to check whether a number is a palindrome.
Category: General
