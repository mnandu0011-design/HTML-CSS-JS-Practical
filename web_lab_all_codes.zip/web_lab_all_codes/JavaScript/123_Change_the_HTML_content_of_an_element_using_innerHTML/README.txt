Experiment 123
Question: Change the HTML content of an element using innerHTML.
Category: General
