Experiment 132
Question: Create a dynamic unordered list from an array.
Category: General
