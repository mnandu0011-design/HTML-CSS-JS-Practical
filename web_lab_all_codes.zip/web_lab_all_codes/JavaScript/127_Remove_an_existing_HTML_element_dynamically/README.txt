Experiment 127
Question: Remove an existing HTML element dynamically.
Category: General
