Experiment 236
Question: Create a webpage that updates information when the browser goes online/offline.
Category: General
