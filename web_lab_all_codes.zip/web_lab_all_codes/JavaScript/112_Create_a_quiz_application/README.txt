Experiment 112
Question: Create a quiz application.
Category: General
