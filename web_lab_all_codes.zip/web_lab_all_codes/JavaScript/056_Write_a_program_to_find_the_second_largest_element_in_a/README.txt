Experiment 56
Question: Write a program to find the second-largest element in an array.
Category: General
