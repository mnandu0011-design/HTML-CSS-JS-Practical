Experiment 27
Question: Create a digital clock using JavaScript.
Category: General
