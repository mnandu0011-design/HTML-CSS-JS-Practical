Experiment 3
Question: Write a program to find the largest of three numbers.
Category: General
