Experiment 171
Question: Create a button that changes font size dynamically.
Category: General
