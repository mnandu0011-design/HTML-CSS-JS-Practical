Experiment 232
Question: Detect whether the browser is online or offline.
Category: General
