Experiment 158
Question: Demonstrate onmouseover and onmouseout.
Category: General
