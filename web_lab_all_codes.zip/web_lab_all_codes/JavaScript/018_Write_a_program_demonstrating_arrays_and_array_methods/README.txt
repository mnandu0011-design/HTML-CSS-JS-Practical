Experiment 18
Question: Write a program demonstrating arrays and array methods.
Category: General
