Experiment 259
Question: Create a CRUD application using localStorage — Create, Read, Update, and Delete records.
Category: General
