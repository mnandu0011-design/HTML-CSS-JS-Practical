Experiment 52
Question: Write a program to check whether a number is a perfect number.
Category: General
