Experiment 67
Question: Write a program to validate an email address using a regular expression.
Category: General
