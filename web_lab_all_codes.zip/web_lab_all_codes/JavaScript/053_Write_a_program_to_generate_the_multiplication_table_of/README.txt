Experiment 53
Question: Write a program to generate the multiplication table of a given number.
Category: General
