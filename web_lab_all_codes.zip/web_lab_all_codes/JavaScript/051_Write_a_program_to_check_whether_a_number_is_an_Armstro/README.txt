Experiment 51
Question: Write a program to check whether a number is an Armstrong number.
Category: General
