Experiment 57
Question: Write a program to remove duplicate elements from an array.
Category: General
