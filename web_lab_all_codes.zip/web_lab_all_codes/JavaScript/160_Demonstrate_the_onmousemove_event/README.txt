Experiment 160
Question: Demonstrate the onmousemove event.
Category: General
