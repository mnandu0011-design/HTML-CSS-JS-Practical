Experiment 17
Question: Write a program demonstrating strings and string methods.
Category: General
