Experiment 188
Question: Validate a mobile phone number.
Category: General
