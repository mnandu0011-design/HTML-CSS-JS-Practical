Experiment 63
Question: Write a program to count vowels and consonants in a string.
Category: General
