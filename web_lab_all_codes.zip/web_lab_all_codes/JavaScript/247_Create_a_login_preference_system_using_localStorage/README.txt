Experiment 247
Question: Create a login preference system using localStorage.
Category: General
