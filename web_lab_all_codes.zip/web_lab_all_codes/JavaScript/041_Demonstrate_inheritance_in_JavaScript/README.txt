Experiment 41
Question: Demonstrate inheritance in JavaScript.
Category: General
