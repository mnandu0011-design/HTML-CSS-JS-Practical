Experiment 149
Question: Create a modal popup using JavaScript.
Category: General
