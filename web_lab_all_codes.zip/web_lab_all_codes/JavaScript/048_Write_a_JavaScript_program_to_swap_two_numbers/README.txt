Experiment 48
Question: Write a JavaScript program to swap two numbers.
Category: General
