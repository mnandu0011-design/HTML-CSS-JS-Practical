Experiment 117
Question: Create a notes application using localStorage.
Category: General
