Experiment 242
Question: Store multiple values using localStorage.
Category: General
