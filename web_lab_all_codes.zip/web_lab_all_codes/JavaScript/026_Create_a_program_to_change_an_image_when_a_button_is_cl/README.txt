Experiment 26
Question: Create a program to change an image when a button is clicked.
Category: General
