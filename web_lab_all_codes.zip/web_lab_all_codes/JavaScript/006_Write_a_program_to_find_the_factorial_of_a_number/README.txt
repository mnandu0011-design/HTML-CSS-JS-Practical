Experiment 6
Question: Write a program to find the factorial of a number.
Category: General
