Experiment 221
Question: Create a form with dynamic fields based on user selection.
Category: General
