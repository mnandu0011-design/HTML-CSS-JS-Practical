Experiment 162
Question: Demonstrate keyboard events using keyup.
Category: General
