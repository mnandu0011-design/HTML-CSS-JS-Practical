Experiment 237
Question: Store a username using localStorage.
Category: General
