Experiment 98
Question: Demonstrate the Window object.
Category: General
