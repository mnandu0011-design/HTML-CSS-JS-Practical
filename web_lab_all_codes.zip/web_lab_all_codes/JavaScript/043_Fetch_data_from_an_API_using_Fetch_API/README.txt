Experiment 43
Question: Fetch data from an API using Fetch API.
Category: General
