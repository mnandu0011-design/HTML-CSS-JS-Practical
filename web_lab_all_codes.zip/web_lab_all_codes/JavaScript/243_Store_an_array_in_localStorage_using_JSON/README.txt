Experiment 243
Question: Store an array in localStorage using JSON.
Category: General
