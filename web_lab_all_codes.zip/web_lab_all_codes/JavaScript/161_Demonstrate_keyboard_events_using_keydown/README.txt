Experiment 161
Question: Demonstrate keyboard events using keydown.
Category: General
