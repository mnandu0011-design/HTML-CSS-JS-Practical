Experiment 258
Question: Create a student marks database using localStorage.
Category: General
