Experiment 111
Question: Create a weather application using an API.
Category: General
