Experiment 202
Question: Prevent form submission when validation fails.
Category: General
