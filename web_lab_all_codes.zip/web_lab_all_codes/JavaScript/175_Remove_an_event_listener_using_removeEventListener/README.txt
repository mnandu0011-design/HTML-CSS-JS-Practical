Experiment 175
Question: Remove an event listener using removeEventListener().
Category: General
