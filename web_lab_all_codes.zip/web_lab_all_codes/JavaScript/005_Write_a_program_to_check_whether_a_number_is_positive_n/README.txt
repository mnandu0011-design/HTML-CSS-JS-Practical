Experiment 5
Question: Write a program to check whether a number is positive, negative, or zero.
Category: General
