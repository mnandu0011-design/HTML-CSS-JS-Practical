Experiment 246
Question: Create a to-do list using localStorage.
Category: General
