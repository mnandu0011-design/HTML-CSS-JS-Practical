Experiment 7
Question: Write a program to generate the Fibonacci series.
Category: General
