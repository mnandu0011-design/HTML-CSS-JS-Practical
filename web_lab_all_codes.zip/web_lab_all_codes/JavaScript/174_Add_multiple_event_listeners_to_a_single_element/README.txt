Experiment 174
Question: Add multiple event listeners to a single element.
Category: General
