Experiment 39
Question: Demonstrate spread and rest operators.
Category: General
