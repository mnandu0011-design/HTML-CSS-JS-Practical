Experiment 152
Question: Create a program to dynamically display the current date and time.
Category: General
