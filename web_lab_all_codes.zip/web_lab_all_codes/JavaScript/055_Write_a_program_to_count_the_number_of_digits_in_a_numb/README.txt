Experiment 55
Question: Write a program to count the number of digits in a number.
Category: General
