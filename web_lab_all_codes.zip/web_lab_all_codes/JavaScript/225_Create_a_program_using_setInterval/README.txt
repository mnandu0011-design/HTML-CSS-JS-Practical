Experiment 225
Question: Create a program using setInterval().
Category: General
