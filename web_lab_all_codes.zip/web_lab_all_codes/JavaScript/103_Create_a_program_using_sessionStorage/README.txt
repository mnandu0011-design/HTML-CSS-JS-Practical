Experiment 103
Question: Create a program using sessionStorage.
Category: General
