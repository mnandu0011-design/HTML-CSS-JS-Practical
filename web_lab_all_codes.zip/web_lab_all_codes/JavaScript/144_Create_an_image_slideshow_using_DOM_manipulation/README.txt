Experiment 144
Question: Create an image slideshow using DOM manipulation.
Category: General
