Experiment 206
Question: Validate a password using a regular expression.
Category: General
