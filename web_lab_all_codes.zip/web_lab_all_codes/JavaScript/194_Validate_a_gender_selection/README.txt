Experiment 194
Question: Validate a gender selection.
Category: General
