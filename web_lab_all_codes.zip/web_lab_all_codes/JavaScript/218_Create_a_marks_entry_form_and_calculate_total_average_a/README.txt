Experiment 218
Question: Create a marks entry form and calculate total, average, and grade.
Category: General
