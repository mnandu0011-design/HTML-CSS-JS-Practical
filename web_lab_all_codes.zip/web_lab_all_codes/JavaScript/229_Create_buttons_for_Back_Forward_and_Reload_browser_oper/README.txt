Experiment 229
Question: Create buttons for Back, Forward, and Reload browser operations.
Category: General
