Experiment 69
Question: Create a program to remove HTML elements dynamically.
Category: General
