# Experiment Index

## HTML
1. [General] Create a basic HTML webpage using **headings, paragraphs, and line breaks**.
2. [General] Create an HTML page containing **ordered, unordered**, and description lists.
3. [General] Create a webpage using **tables** with rows, columns, borders, and merged cells.
4. [General] Create an HTML page containing images and **hyperlinks**.
5. [General] Create a student registration **form** using HTML form elements.
6. [General] Create a webpage using **audio** and **video** elements.
7. [General] Create a webpage using frames/**iframes**.
8. [General] Create an HTML page demonstrating semantic elements such as \<header>, \<nav>, \<section>, \<article>, and \<footer>.
9. [General] Create a webpage using HTML5 **input** types such as email, date, number, and password.
10. [General] Create a college timetable using an HTML **table**.
11. [General] Create a webpage with **internal** and **external CSS** styling.
12. [General] Create a webpage demonstrating CSS **selectors, colors, fonts, margins, padding, and borders**.
13. [General] Create a responsive webpage using **CSS media queries**.
14. [General] Create a webpage using Bootstrap components.
15. [General] Create a simple personal portfolio webpage using HTML and CSS.

## CSS
1. [General] Create a webpage using Inline, Internal, and External CSS.
2. [General] Create a webpage using Universal, Element, Class, ID, Attribute, and Grouping selectors.
3. [General] Create a webpage using Descendant, Child, Adjacent Sibling, and General Sibling selectors.
4. [General] Create a webpage using CSS colors for text, backgrounds, borders, and UI elements.
5. [General] Create a webpage using background images, background colors, background positioning, sizing, repeat, and attachment.
6. [General] Create a webpage using different CSS border styles, widths, colors, and border-radius properties.
7. [General] Create a webpage using Linear and Radial CSS gradients.
8. [General] Create a webpage using CSS font-family, font-size, font-weight, font-style, and font-variant properties.
9. [General] Create a webpage using CSS text alignment, decoration, transformation, indentation, spacing, and line-height.
10. [General] Create a webpage using the CSS box model with content, padding, border, and margin.
11. [General] Create a webpage using different width, height, min-width, max-width, min-height, and max-height properties.
12. [General] Create a webpage using the CSS box-sizing property with content-box and border-box.
13. [General] Create a webpage using CSS display properties such as block, inline, inline-block, flex, grid, and none.
14. [General] Create a webpage using CSS visibility and opacity properties.
15. [General] Create a webpage using CSS overflow, overflow-x, and overflow-y properties.
16. [General] Create a webpage using border-radius to create rounded cards, circles, pills, and custom shapes.
17. [General] Create a webpage using CSS box-shadow and text-shadow properties.
18. [General] Create a webpage using CSS variables and custom properties.
19. [General] Create a webpage using CSS inheritance, specificity, and the cascade.
20. [General] Create a webpage using CSS calc(), min(), max(), and clamp() functions.
21. [General] Create a webpage using static, relative, absolute, fixed, and sticky positioning.
22. [General] Create a webpage using z-index and CSS stacking order.
23. [General] Create a webpage using float and clear properties.
24. [General] Create a webpage using different CSS cursor styles and pointer interactions.
25. [General] Create a webpage using CSS outline and outline-offset properties.
26. [General] Create a webpage using CSS margin, padding, and spacing utilities.
27. [General] Create a webpage using CSS width and height percentages, viewport units, and rem units.
28. [General] Create a webpage using CSS em, rem, vw, vh, and percentage units.
29. [General] Create a webpage using CSS object-fit and object-position properties.
30. [General] Create a webpage using CSS filters such as blur, grayscale, brightness, contrast, and opacity.
31. [General] Create a webpage using CSS transitions for colors, sizes, shadows, and positions.
32. [General] Create a webpage using CSS 2D transformations such as rotate, scale, translate, and skew.
33. [General] Create a webpage using CSS 3D transformations and perspective effects.
34. [General] Create a webpage using CSS keyframe animations.
35. [General] Create a webpage using a CSS loading spinner and loading animation.
36. [General] Create a webpage for a SaaS navigation bar.
37. [General] Create a webpage for a SaaS sidebar navigation.
38. [General] Create a webpage for a responsive SaaS navigation menu.
39. [General] Create a webpage for a mobile sidebar navigation drawer.
40. [General] Create a webpage for a dropdown navigation menu.
41. [General] Create a webpage for a mega navigation menu.
42. [General] Create a webpage for a breadcrumb navigation component.
43. [General] Create a webpage for a tab navigation component.
44. [General] Create a webpage for a pill navigation component.
45. [General] Create a webpage for a pagination component.
46. [General] Create a webpage for a SaaS card component.
47. [General] Create a webpage for a profile card component.
48. [General] Create a webpage for a product card component.
49. [General] Create a webpage for a feature card component.
50. [General] Create a webpage for a pricing card component.
51. [General] Create a webpage for a SaaS statistics card component.
52. [General] Create a webpage for a KPI and metric card component.
53. [General] Create a webpage for a dashboard card component.
54. [General] Create a webpage for a notification card component.
55. [General] Create a webpage for an activity feed card component.
56. [General] Create a webpage for a testimonial card component.
57. [General] Create a webpage for a SaaS hero section.
58. [General] Create a webpage for a SaaS landing page header.
59. [General] Create a webpage for primary, secondary, outline, and destructive buttons.
60. [General] Create a webpage for icon buttons and action buttons.
61. [General] Create a webpage for badges, labels, tags, and chips.
62. [General] Create a webpage for user avatars and avatar groups.
63. [General] Create a webpage for dividers and section separators.
64. [General] Create a webpage for alert and notification components.
65. [General] Create a webpage for toast notification components.
66. [General] Create a webpage for tooltip components.
67. [General] Create a webpage for popover components.
68. [General] Create a webpage for modal and dialog components.
69. [General] Create a webpage for confirmation dialog components.
70. [General] Create a webpage for a drawer and slide-out panel.
71. [General] Create a webpage for a command palette interface.
72. [General] Create a webpage for an accordion component.
73. [General] Create a webpage for an empty-state component.
74. [General] Create a webpage for an error-state component.
75. [General] Create a webpage for a success-state component.
76. [General] Create a webpage for a loading-state component.
77. [General] Create a webpage for a skeleton-loading component.
78. [General] Create a webpage for a progress bar component.
79. [General] Create a webpage for a progress stepper component.
80. [General] Create a webpage for a timeline and activity history component.
81. [General] Create a webpage for a login form.
82. [General] Create a webpage for a signup form.
83. [General] Create a webpage for a forgot-password form.
84. [General] Create a webpage for a reset-password form.
85. [General] Create a webpage for a registration form.
86. [General] Create a webpage for a contact form.
87. [General] Create a webpage for a multi-step form.
88. [General] Create a webpage for form validation and error messages.
89. [General] Create a webpage for a SaaS dashboard.
90. [General] Create a webpage for an admin dashboard.
91. [General] Create a webpage for an analytics dashboard.
92. [General] Create a webpage for a KPI analytics dashboard.
93. [General] Create a webpage for a revenue analytics dashboard.
94. [General] Create a webpage for a sales analytics dashboard.
95. [General] Create a webpage for user analytics.
96. [General] Create a webpage for customer analytics.
97. [General] Create a webpage for product analytics.
98. [General] Create a webpage for marketing analytics.
99. [General] Create a webpage for financial analytics.
100. [General] Create a webpage for real-time analytics.
101. [General] Create a webpage for SaaS usage analytics.
102. [General] Create a webpage for a conversion funnel dashboard.
103. [General] Create a webpage for a retention and cohort analytics dashboard.
104. [General] Create a webpage for a revenue chart dashboard.
105. [General] Create a webpage for a line chart analytics component.
106. [General] Create a webpage for a bar chart analytics component.
107. [General] Create a webpage for an area chart analytics component.
108. [General] Create a webpage for a pie and donut chart analytics component.
109. [General] Create a webpage for a heatmap analytics component.
110. [General] Create a webpage for data visualization cards.
111. [General] Create a webpage for an analytics date-range filter.
112. [General] Create a webpage for an analytics filter and sorting panel.
113. [General] Create a webpage for customizable dashboard widgets.
114. [General] Create a webpage for a customizable analytics dashboard.
115. [General] Create a webpage for an analytics report and export interface.
116. [General] Create a webpage for an AI assistant interface.
117. [General] Create a webpage for an AI chat interface.
118. [General] Create a webpage for an AI chat sidebar.
119. [General] Create a webpage for an AI command bar.
120. [General] Create a webpage for an AI-powered search interface.
121. [General] Create a webpage for AI search results.
122. [General] Create a webpage for an AI prompt input interface.
123. [General] Create a webpage for AI prompt suggestions.
124. [General] Create a webpage for an AI response card.
125. [General] Create a webpage for an AI-generated content card.
126. [General] Create a webpage for an AI summary card.
127. [General] Create a webpage for an AI recommendation card.
128. [General] Create a webpage for an AI insight card.
129. [General] Create a webpage for an AI copilot interface.
130. [General] Create a webpage for an AI autocomplete interface.
131. [General] Create a webpage for AI smart suggestions.
132. [General] Create a webpage for an AI content generator.
133. [General] Create a webpage for an AI document summarizer.
134. [General] Create a webpage for an AI data analysis interface.
135. [General] Create a webpage for a natural-language query interface.
136. [General] Create a webpage for an Ask Your Data interface.
137. [General] Create a webpage for a text-to-chart analytics interface.
138. [General] Create a webpage for an AI report generator.
139. [General] Create a webpage for an AI-powered analytics dashboard.
140. [General] Create a webpage for an AI prediction card.
141. [General] Create a webpage for an AI forecasting dashboard.
142. [General] Create a webpage for an anomaly detection dashboard.
143. [General] Create a webpage for an AI confidence score component.
144. [General] Create a webpage for an AI sources and citations component.
145. [General] Create a webpage for an AI explanation and reasoning interface.
146. [General] Create a webpage for an AI agent dashboard.
147. [General] Create a webpage for an AI agent list.
148. [General] Create a webpage for an AI agent profile.
149. [General] Create a webpage for AI agent status monitoring.
150. [General] Create a webpage for an AI agent task queue.
151. [General] Create a webpage for an AI agent activity log.
152. [General] Create a webpage for an AI agent execution history.
153. [General] Create a webpage for an AI agent execution timeline.
154. [General] Create a webpage for an AI agent workflow.
155. [General] Create a webpage for an AI agent builder.
156. [General] Create a webpage for AI agent configuration settings.
157. [General] Create a webpage for AI agent permissions management.
158. [General] Create a webpage for an AI agent approval interface.
159. [General] Create a webpage for a human-in-the-loop AI workflow.
160. [General] Create a webpage for an AI agent error and retry interface.
161. [General] Create a webpage for AI agent monitoring.
162. [General] Create a webpage for multi-agent workflow management.
163. [General] Create a webpage for an automation workflow builder.
164. [General] Create a webpage for a trigger and action workflow.
165. [General] Create a webpage for an ML prediction dashboard.
166. [General] Create a webpage for an ML forecast chart.
167. [General] Create a webpage for an ML probability score component.
168. [General] Create a webpage for an ML confidence score component.
169. [General] Create a webpage for an ML risk score dashboard.
170. [General] Create a webpage for a recommendation engine interface.
171. [General] Create a webpage for an ML anomaly alert.
172. [General] Create a webpage for an ML outlier detection interface.
173. [General] Create a webpage for an ML classification result.
174. [General] Create a webpage for an ML prediction comparison dashboard.
175. [General] Create a webpage for an ML model performance dashboard.
176. [General] Create a webpage for ML model metrics.
177. [General] Create a webpage for ML model version management.
178. [General] Create a webpage for ML model monitoring.
179. [General] Create a webpage for ML data drift monitoring.
180. [General] Create a webpage for ML feature importance visualization.
181. [General] Create a webpage for ML prediction explanation.
182. [General] Create a webpage for an ML experiment dashboard.
183. [General] Create a webpage for account settings.
184. [General] Create a webpage for profile settings.
185. [General] Create a webpage for team management.
186. [General] Create a webpage for user management.
187. [General] Create a webpage for role and permission management.
188. [General] Create a webpage for organization settings.
189. [General] Create a webpage for API key management.
190. [General] Create a webpage for API usage analytics.
191. [General] Create a webpage for integrations management.
192. [General] Create a webpage for webhook management.
193. [General] Create a webpage for developer settings.
194. [General] Create a webpage for security settings.
195. [General] Create a webpage for two-factor authentication settings.
196. [General] Create a webpage for active sessions and device management.
197. [General] Create a webpage for an audit log.
198. [General] Create a webpage for SaaS pricing plans.
199. [General] Create a webpage for pricing plan comparison.
200. [General] Create a webpage for subscription management.
201. [General] Create a webpage for subscription upgrade and downgrade.
202. [General] Create a webpage for a SaaS billing dashboard.
203. [General] Create a webpage for payment method management.
204. [General] Create a webpage for invoice management.
205. [General] Create a webpage for invoice details.
206. [General] Create a webpage for usage-based billing.
207. [General] Create a webpage for usage and consumption meters.
208. [General] Create a webpage for AI token and credit usage.
209. [General] Create a webpage for AI spending limits.
210. [General] Create a webpage for billing alerts.
211. [General] Create a webpage for a responsive Flexbox layout.
212. [General] Create a webpage for a responsive CSS Grid layout.
213. [General] Create a webpage for a responsive SaaS dashboard.
214. [General] Create a webpage for a responsive data table.
215. [General] Create a webpage for responsive SaaS cards.
216. [General] Create a webpage for a responsive SaaS form.
217. [General] Create a webpage for a responsive analytics dashboard.
218. [General] Create a webpage for responsive charts and data visualization.
219. [General] Create a webpage for a responsive pricing page.
220. [General] Create a webpage for a responsive login page.
221. [General] Create a webpage for a responsive signup page.
222. [General] Create a webpage for a mobile-first SaaS layout.
223. [General] Create a webpage for a mobile bottom navigation.
224. [General] Create a webpage for a sticky SaaS header.
225. [General] Create a webpage for a fixed SaaS sidebar.
226. [General] Create a webpage for a responsive SaaS footer.
227. [General] Create a webpage for a responsive photo and media gallery.
228. [General] Create a webpage for CSS hover effects and micro-interactions.
229. [General] Create a webpage for animated SaaS cards and components.
230. [General] Create a webpage for a CSS sliding card animation.
231. [General] Create a webpage for a CSS-only modal and popup interface.
232. [General] Create a webpage for a dark-mode SaaS interface using CSS variables.
233. [General] Create a webpage for a light and dark theme switcher.
234. [General] Create a webpage for responsive SaaS typography.
235. [General] Create a webpage for a glassmorphism SaaS interface.
236. [General] Create a webpage for a gradient-based SaaS interface.
237. [General] Create a webpage for a SaaS command palette with keyboard shortcuts.
238. [General] Create a webpage for an AI notification center.
239. [General] Create a webpage for a SaaS user profile menu.
240. [General] Create a webpage for a SaaS onboarding workflow.
241. [General] Create a webpage for a SaaS help and support interface.
242. [General] Create a webpage for a SaaS documentation interface.
243. [General] Create a webpage for a SaaS search and filter interface.
244. [General] Create a webpage for a SaaS calendar and scheduling interface.
245. [General] Create a webpage for a SaaS file management interface.
246. [General] Create a webpage for a SaaS collaboration and team workspace.
247. [General] Final SaaS Webpage Projects
248. [General] Create a webpage for a complete SaaS landing page.
249. [General] Create a webpage for a SaaS login page.
250. [General] Create a webpage for a SaaS signup page.
251. [General] Create a webpage for a SaaS onboarding page.
252. [General] Create a webpage for a complete SaaS dashboard.
253. [General] Create a webpage for a complete analytics dashboard.
254. [General] Create a webpage for an AI-powered SaaS dashboard.
255. [General] Create a webpage for an AI agent management dashboard.
256. [General] Create a webpage for a SaaS user management system.
257. [General] Create a webpage for a SaaS team management system.
258. [General] Create a webpage for a SaaS account settings page.
259. [General] Create a webpage for a SaaS security settings page.
260. [General] Create a webpage for a SaaS integrations page.
261. [General] Create a webpage for a SaaS billing management page.
262. [General] Create a webpage for a SaaS pricing page.
263. [General] Create a webpage for a SaaS checkout page.
264. [General] Create a webpage for a SaaS invoice management page.
265. [General] Create a webpage for a SaaS help center.
266. [General] Create a webpage for a SaaS documentation website.
267. [General] Create a webpage for a SaaS blog and news website.
268. [General] Create a webpage for a SaaS 404 error page.
269. [General] Create a webpage for a SaaS 500 error page.
270. [General] Create a webpage for a complete responsive SaaS website using HTML5, CSS3, Flexbox, Grid, media queries, analytics, AI/ML interfaces, dashboards, and modern SaaS components.

## JavaScript
1. [General] Write a JavaScript program to display “Hello World”.
2. [General] Write a JavaScript program to perform arithmetic operations.
3. [General] Write a program to find the largest of three numbers.
4. [General] Write a program to check whether a number is even or odd.
5. [General] Write a program to check whether a number is positive, negative, or zero.
6. [General] Write a program to find the factorial of a number.
7. [General] Write a program to generate the Fibonacci series.
8. [General] Write a program to check whether a number is prime.
9. [General] Write a program to check whether a number is a palindrome.
10. [General] Write a program to reverse a number.
11. [General] Write a program to find the sum of digits of a number.
12. [General] Write a program to find the largest and smallest element in an array.
13. [General] Write a program to sort an array.
14. [General] Write a program to find the sum and average of array elements.
15. [General] Write a program to demonstrate JavaScript functions.
16. [General] Write a program using arrow functions.
17. [General] Write a program demonstrating strings and string methods.
18. [General] Write a program demonstrating arrays and array methods.
19. [General] Write a program demonstrating objects in JavaScript.
20. [General] Write a program demonstrating Date and Math objects.
21. [General] DOM & Event-Based Experiments
22. [General] Create a webpage that changes text using JavaScript.
23. [General] Change the background color of a webpage using JavaScript.
24. [General] Create a button click event using JavaScript.
25. [General] Create a program to show/hide an HTML element.
26. [General] Create a program to change an image when a button is clicked.
27. [General] Create a digital clock using JavaScript.
28. [General] Create a simple calculator using HTML, CSS, and JavaScript.
29. [General] Create a number guessing game.
30. [General] Create a form validation program.
31. [General] Validate name, email, phone number, and password using JavaScript.
32. [General] Create a to-do list using JavaScript.
33. [General] Create a simple quiz application.
34. [General] Create a counter application with increment and decrement buttons.
35. [General] Create a stopwatch using JavaScript.
36. [General] Create a countdown timer using JavaScript.
37. [General] Advanced JavaScript Lab Questions
38. [General] Demonstrate ES6 let, const, template literals, and destructuring.
39. [General] Demonstrate spread and rest operators.
40. [General] Demonstrate classes and objects.
41. [General] Demonstrate inheritance in JavaScript.
42. [General] Demonstrate callbacks, promises, and async/await.
43. [General] Fetch data from an API using Fetch API.
44. [General] Display API data dynamically on a webpage.
45. [General] Store and retrieve data using localStorage.
46. [General] Create a responsive login form with JavaScript validation.
47. [General] Create a complete interactive webpage using HTML, CSS, and JavaScript.
48. [General] Write a JavaScript program to swap two numbers.
49. [General] Write a program to find the greatest common divisor (GCD) of two numbers.
50. [General] Write a program to find the least common multiple (LCM) of two numbers.
51. [General] Write a program to check whether a number is an Armstrong number.
52. [General] Write a program to check whether a number is a perfect number.
53. [General] Write a program to generate the multiplication table of a given number.
54. [General] Write a program to calculate the power of a number.
55. [General] Write a program to count the number of digits in a number.
56. [General] Write a program to find the second-largest element in an array.
57. [General] Write a program to remove duplicate elements from an array.
58. [General] Write a program to merge two arrays.
59. [General] Write a program to find the frequency of each element in an array.
60. [General] Write a program to find common elements in two arrays.
61. [General] Write a program to reverse a string.
62. [General] Write a program to check whether a string is a palindrome.
63. [General] Write a program to count vowels and consonants in a string.
64. [General] Write a program to count the number of words in a string.
65. [General] Write a program to find the frequency of characters in a string.
66. [General] Write a program to demonstrate regular expressions in JavaScript.
67. [General] Write a program to validate an email address using a regular expression.
68. [General] Create a webpage and use JavaScript to add new elements dynamically.
69. [General] Create a program to remove HTML elements dynamically.
70. [General] Create a program to change CSS styles using JavaScript.
71. [General] Create a program to change multiple HTML elements simultaneously.
72. [General] Demonstrate getElementById() and getElementsByClassName().
73. [General] Demonstrate querySelector() and querySelectorAll().
74. [General] Create a program to create and remove CSS classes dynamically.
75. [General] Create a dynamic table using JavaScript.
76. [General] Create a program to add and delete rows from a table.
77. [General] Create a program to search/filter table records.
78. [General] Create a live character counter for a textarea.
79. [General] Create a password show/hide feature.
80. [General] Create a dynamic dropdown list.
81. [General] Create a dependent dropdown such as Country → State → City.
82. [General] Create an image slideshow/carousel using JavaScript.
83. [General] Demonstrate mouse events using JavaScript.
84. [General] Demonstrate keyboard events using JavaScript.
85. [General] Demonstrate form events such as submit, change, focus, and blur.
86. [General] Create a webpage that responds to double-click events.
87. [General] Create a program using event bubbling and event capturing.
88. [General] Demonstrate event delegation.
89. [General] Create a keyboard-controlled webpage/game.
90. [General] Create a drag-and-drop application using JavaScript.
91. [General] Create a student registration form with JavaScript validation.
92. [General] Create a login form with username and password validation.
93. [General] Create a password strength checker.
94. [General] Create a signup form with password confirmation.
95. [General] Create a feedback form with validation.
96. [General] Create a college admission form with JavaScript validation.
97. [General] Display validation error messages dynamically without reloading the page.
98. [General] Demonstrate the Window object.
99. [General] Demonstrate the Navigator object.
100. [General] Demonstrate the Location object.
101. [General] Demonstrate the History object.
102. [General] Create a program using localStorage.
103. [General] Create a program using sessionStorage.
104. [General] Create a shopping cart using localStorage.
105. [General] Create a theme switcher (light/dark mode) using localStorage.
106. [General] Create a digital calculator.
107. [General] Create a digital clock.
108. [General] Create a stopwatch.
109. [General] Create a countdown timer.
110. [General] Create a to-do list application.
111. [General] Create a weather application using an API.
112. [General] Create a quiz application.
113. [General] Create a tic-tac-toe game.
114. [General] Create a simple expense tracker.
115. [General] Create a student marks/grade calculator.
116. [General] Create a simple shopping cart.
117. [General] Create a notes application using localStorage.
118. [General] Create a random password generator.
119. [General] Create a BMI calculator.
120. [General] Create a currency converter using an API.
121. [General] Create a complete interactive portfolio website using HTML, CSS, and JavaScript.
122. [General] Change the text content of an HTML element using JavaScript.
123. [General] Change the HTML content of an element using innerHTML.
124. [General] Change the style of an HTML element dynamically.
125. [General] Change the background color of an element when a button is clicked.
126. [General] Create a new HTML element dynamically and add it to the webpage.
127. [General] Remove an existing HTML element dynamically.
128. [General] Replace an existing HTML element with a new element.
129. [General] Add and remove CSS classes using JavaScript.
130. [General] Toggle a CSS class using JavaScript.
131. [General] Change the attributes of an HTML element dynamically.
132. [General] Create a dynamic unordered list from an array.
133. [General] Create a dynamic ordered list from user input.
134. [General] Create a dynamic student table using JavaScript.
135. [General] Add new rows to an HTML table dynamically.
136. [General] Delete a selected row from an HTML table.
137. [General] Edit table data dynamically.
138. [General] Create a searchable/filterable table.
139. [General] Sort table records using JavaScript.
140. [General] Create a dynamic dropdown menu using JavaScript.
141. [General] Add options dynamically to a \<select> element.
142. [General] Create a dependent dropdown — Country → State → City.
143. [General] Create an image gallery dynamically from an array of image data.
144. [General] Create an image slideshow using DOM manipulation.
145. [General] Create a show/hide password feature.
146. [General] Create a show/hide content button.
147. [General] Create a tabs interface using DOM manipulation.
148. [General] Create an accordion using JavaScript.
149. [General] Create a modal popup using JavaScript.
150. [General] Create a tooltip dynamically.
151. [General] Create a live word counter.
152. [General] Create a program to dynamically display the current date and time.
153. [General] Create a to-do list using DOM manipulation.
154. [General] Create a program to add, edit, and delete to-do items.
155. [General] Demonstrate createElement(), appendChild(), remove(), and replaceChild().
156. [General] Demonstrate the onclick event.
157. [General] Demonstrate the ondblclick event.
158. [General] Demonstrate onmouseover and onmouseout.
159. [General] Demonstrate onmousedown and onmouseup.
160. [General] Demonstrate the onmousemove event.
161. [General] Demonstrate keyboard events using keydown.
162. [General] Demonstrate keyboard events using keyup.
163. [General] Create a webpage that displays the key pressed by the user.
164. [General] Create a program that counts the number of keyboard key presses.
165. [General] Demonstrate the focus and blur events.
166. [General] Demonstrate the change event.
167. [General] Demonstrate the input event.
168. [General] Demonstrate the submit event.
169. [General] Demonstrate the reset event.
170. [General] Create a button that changes the background color when clicked.
171. [General] Create a button that changes font size dynamically.
172. [General] Create a webpage with multiple buttons having different event handlers.
173. [General] Demonstrate event listeners using addEventListener().
174. [General] Add multiple event listeners to a single element.
175. [General] Remove an event listener using removeEventListener().
176. [General] Demonstrate event bubbling.
177. [General] Demonstrate event capturing.
178. [General] Create a drag-and-drop application.
179. [General] Create a mouse coordinate tracker.
180. [General] Create a keyboard-controlled moving object.
181. [General] Create a click counter.
182. [General] Create a double-click counter.
183. [General] Create a reaction-time game.
184. [General] Create a simple keyboard typing test.
185. [General] Create a student registration form and validate all fields.
186. [General] Validate a name field to accept only alphabets.
187. [General] Validate an age field using JavaScript.
188. [General] Validate a mobile phone number.
189. [General] Validate an email address.
190. [General] Validate a password based on minimum length.
191. [General] Create a strong password validator.
192. [General] Validate password and confirm password fields.
193. [General] Validate a date of birth field.
194. [General] Validate a gender selection.
195. [General] Validate radio buttons.
196. [General] Validate checkbox selection.
197. [General] Validate a dropdown/select box.
198. [General] Validate a textarea.
199. [General] Create a form with required-field validation.
200. [General] Display error messages beside individual form fields.
201. [General] Display a success message after successful form submission.
202. [General] Prevent form submission when validation fails.
203. [General] Validate a form using regular expressions.
204. [General] Validate an email using a regular expression.
205. [General] Validate a phone number using a regular expression.
206. [General] Validate a password using a regular expression.
207. [General] Create a real-time form validation system.
208. [General] Validate fields using the input, change, focus, and blur events.
209. [General] Create a password strength meter.
210. [General] Create a show/hide password option.
211. [General] Create a registration form with password confirmation.
212. [General] Create a college admission form with complete validation.
213. [General] Create a job application form with validation.
214. [General] Create a contact form with validation.
215. [General] Create a multi-step registration form.
216. [General] Create a form that displays a preview of entered information before submission.
217. [General] Create a form that calculates and displays age from date of birth.
218. [General] Create a marks entry form and calculate total, average, and grade.
219. [General] Create an employee salary form and calculate salary details.
220. [General] Create a shopping order form and calculate the total price.
221. [General] Create a form with dynamic fields based on user selection.
222. [General] Create a form that validates input and displays errors without page reload.
223. [General] Demonstrate alert(), confirm(), and prompt().
224. [General] Create a program using setTimeout().
225. [General] Create a program using setInterval().
226. [General] Create a digital clock using setInterval().
227. [General] Create a button to redirect the user to another webpage.
228. [General] Display the current webpage URL using JavaScript.
229. [General] Create buttons for Back, Forward, and Reload browser operations.
230. [General] Display browser information using JavaScript.
231. [General] Display the user's screen width and height.
232. [General] Detect whether the browser is online or offline.
233. [General] Display the current browser language.
234. [General] Demonstrate browser geolocation.
235. [General] Display the user's current geographical coordinates using the Geolocation API.
236. [General] Create a webpage that updates information when the browser goes online/offline.
237. [General] Store a username using localStorage.
238. [General] Retrieve and display data from localStorage.
239. [General] Update data stored in localStorage.
240. [General] Delete an item from localStorage.
241. [General] Clear all localStorage data.
242. [General] Store multiple values using localStorage.
243. [General] Store an array in localStorage using JSON.
244. [General] Store a JavaScript object in localStorage.
245. [General] Create a student record system using localStorage.
246. [General] Create a to-do list using localStorage.
247. [General] Create a login preference system using localStorage.
248. [General] Create a dark/light theme switcher using localStorage.
249. [General] Save the user's preferred font size using localStorage.
250. [General] Create a recently viewed items feature using localStorage.
251. [General] Create a visitor counter using browser storage.
252. [General] Compare localStorage and sessionStorage.
253. [General] Store temporary form data using sessionStorage.
254. [General] Create a multi-page form using sessionStorage.
255. [General] Save form data automatically using localStorage.
256. [General] Restore previously entered form data after refreshing the page.
257. [General] Create a shopping cart that persists after page refresh.
258. [General] Create a student marks database using localStorage.
259. [General] Create a CRUD application using localStorage — Create, Read, Update, and Delete records.

## MySQL
1. [General] Database Fundamentals
2. [General] Create a database using MySQL.
3. [General] Create and delete tables using MySQL.
4. [General] Demonstrate different MySQL data types.
5. [General] Demonstrate primary key and foreign key.
6. [General] Implement NOT NULL, UNIQUE, DEFAULT, and CHECK constraints.
7. [General] Alter table structure using ALTER TABLE.
8. [General] Rename and truncate tables.
9. [SQL_Commands] Insert records using INSERT.
10. [SQL_Commands] Retrieve records using SELECT.
11. [SQL_Commands] Update records using UPDATE.
12. [SQL_Commands] Delete records using DELETE.
13. [SQL_Commands] Use WHERE clause for filtering records.
14. [SQL_Commands] Use ORDER BY for sorting records.
15. [SQL_Commands] Use DISTINCT to retrieve unique values.
16. [SQL_Commands] Use LIMIT to restrict query results.
17. [SQL_Operators_Functions] Demonstrate arithmetic operators in SQL.
18. [SQL_Operators_Functions] Demonstrate comparison and logical operators.
19. [SQL_Operators_Functions] Use LIKE, IN, and BETWEEN operators.
20. [SQL_Operators_Functions] Demonstrate aggregate functions: COUNT(), SUM(), AVG(), MIN(), and MAX().
21. [SQL_Operators_Functions] Demonstrate string functions.
22. [SQL_Operators_Functions] Demonstrate date and time functions.
23. [SQL_Operators_Functions] Demonstrate GROUP BY and HAVING.
24. [Joins] Implement INNER JOIN.
25. [Joins] Implement LEFT JOIN.
26. [Joins] Implement RIGHT JOIN.
27. [Joins] Implement self join.
28. [Joins] Implement multiple-table joins.
29. [Subqueries] Implement single-row subqueries.
30. [Subqueries] Implement multiple-row subqueries.
31. [Subqueries] Implement subqueries with IN.
32. [Subqueries] Implement correlated subqueries.
33. [Views_Indexes] Create and use views.
34. [Views_Indexes] Update and delete views.
35. [Views_Indexes] Create indexes on tables.
36. [Views_Indexes] Demonstrate unique indexes.
37. [Views_Indexes] Drop indexes.
38. [Stored_Procedures_Functions] Create and execute a stored procedure.
39. [Stored_Procedures_Functions] Create a stored procedure with parameters.
40. [Stored_Procedures_Functions] Create a stored function.
41. [Stored_Procedures_Functions] Use conditional statements inside stored procedures.
42. [Stored_Procedures_Functions] Use loops inside stored procedures.
43. [Triggers] Create a BEFORE INSERT trigger.
44. [Triggers] Create an AFTER INSERT trigger.
45. [Triggers] Create an BEFORE UPDATE trigger.
46. [Triggers] Create an AFTER DELETE trigger.
47. [Triggers] Implement an audit table using triggers.
48. [Transactions] Demonstrate transactions in MySQL.
49. [Transactions] Implement COMMIT.
50. [Transactions] Implement ROLLBACK.
51. [Transactions] Demonstrate SAVEPOINT.
52. [Transactions] Demonstrate transaction handling with multiple SQL operations.
53. [Database_Design] Design a Student Management Database.
54. [Database_Design] Design a User Management Database.
55. [Database_Design] Design a Product Management Database.
56. [Database_Design] Design a Library Management Database.
57. [Database_Design] Implement relationships between multiple tables.
58. [Database_Design] Implement normalization using 1NF, 2NF, and 3NF.
59. [CRUD] Implement CRUD operations using SQL.
60. [CRUD] Create a Student Management CRUD database.
61. [CRUD] Create a User Management CRUD database.
62. [CRUD] Create a Product Management CRUD database.
63. [CRUD] Implement CRUD operations using multiple related tables.
64. [CRUD] Implement input constraints for CRUD operations.
65. [Advanced_SQL] Implement UNION and UNION ALL.
66. [Advanced_SQL] Implement CASE statements.
67. [Advanced_SQL] Implement Common Table Expressions (CTEs).
68. [Advanced_SQL] Demonstrate window functions.
69. [Advanced_SQL] Implement EXISTS and NOT EXISTS.
70. [Advanced_SQL] Demonstrate ON DELETE CASCADE and ON UPDATE CASCADE.
71. [Advanced_SQL] Export and import a MySQL database.
72. [Advanced_SQL] Backup and restore a MySQL database.

## NodeJS
1. [General] Implement a basic Client-Server Architecture using Node.js.
2. [General] Create a basic HTTP Server using Node.js.
3. [General] Demonstrate the Request-Response Cycle in a server-side application.
4. [General] Node.js Fundamentals
5. [General] Create a Node.js application using built-in modules.
6. [General] Demonstrate the File System (fs) module.
7. [General] Demonstrate the Path (path) module.
8. [General] Create and use custom Node.js modules.
9. [General] Install and use packages using npm.
10. [General] Demonstrate Callbacks, Promises, and Async/Await in Node.js.
11. [General] Implement Error Handling in a Node.js application.
12. [General] Create a basic Express.js application.
13. [General] Handle GET and POST requests using Express.
14. [General] Serve static files using Express.
15. [General] Send HTML and JSON responses using Express.
16. [General] Create an Express application with a modular project structure.
17. [General] Implement basic routing using Express.
18. [General] Implement route parameters and query parameters.
19. [General] Create multiple routes using Express Router.
20. [General] Implement 404 / Not Found route handling.
21. [General] Create modular routes for users, products, or students.
22. [General] Create and implement custom middleware.
23. [General] Implement logging middleware.
24. [General] Implement request validation middleware.
25. [General] Implement authentication middleware.
26. [General] Implement error-handling middleware.
27. [General] Demonstrate the execution order of middleware.
28. [General] Create and manage cookies using Express.
29. [General] Read and delete cookies using Express.
30. [General] Implement session management in Express.
31. [General] Implement login and logout using sessions.
32. [General] Create protected routes using session authentication.
33. [General] Connect a Node.js application to a database.
34. [General] Create and manage database tables/collections.
35. [General] Insert data into a database using Node.js.
36. [General] Retrieve data from a database using Node.js.
37. [General] Update database records using Node.js.
38. [General] Delete database records using Node.js.
39. [General] Implement CRUD operations using Node.js and Express.
40. [General] Create a Student Management CRUD application.
41. [General] Create a User Management CRUD application.
42. [General] Create a Product Management CRUD application.
43. [General] Implement CRUD operations with database connectivity.
44. [General] Implement input validation for CRUD operations.
45. [General] Implement User Registration.
46. [General] Implement User Login and Logout.
47. [General] Implement Password Hashing.
48. [General] Implement Password Verification.
49. [General] Implement JWT-based Authentication.
50. [General] Create Protected API Routes using authentication.
51. [General] Implement Role-Based Authorization.
52. [General] Create Admin and User roles.
53. [General] Restrict specific routes based on user roles.
54. [General] Implement Authorization Middleware.
55. [General] RESTful API Development
56. [General] Create a basic RESTful API using Express.js.
57. [General] Implement a GET REST API.
58. [General] Implement a POST REST API.
59. [General] Implement a PUT/PATCH REST API.
60. [General] Implement a DELETE REST API.
61. [General] Implement proper HTTP Status Codes in REST APIs.
62. [General] Implement API Error Handling.
63. [General] Implement API Request Validation.
64. [General] Test REST APIs using Postman.
65. [General] Create a Student REST API with Database Connectivity.
66. [General] Create a Product REST API with CRUD Operations.
67. [General] Create a User REST API with Authentication and Authorization.

## Supabase
1. [Supabase_Fundamentals] Create a Supabase project.
2. [Supabase_Fundamentals] Explore the Supabase Dashboard.
3. [Supabase_Fundamentals] Configure project settings and API keys.
4. [Supabase_Fundamentals] Create and manage a PostgreSQL database using Supabase.
5. [Supabase_Fundamentals] Demonstrate Supabase Table Editor.
6. [Supabase_Fundamentals] Demonstrate Supabase SQL Editor.
7. [Supabase_Fundamentals] Connect an application to Supabase.
8. [Database_Tables] Create tables using Supabase.
9. [Database_Tables] Define columns and PostgreSQL data types.
10. [Database_Tables] Implement primary keys and foreign keys.
11. [Database_Tables] Implement NOT NULL, UNIQUE, DEFAULT, and CHECK constraints.
12. [Database_Tables] Insert records into Supabase tables.
13. [Database_Tables] Retrieve records from Supabase tables.
14. [Database_Tables] Update records in Supabase tables.
15. [Database_Tables] Delete records from Supabase tables.
16. [SQL_Operations] Execute basic SELECT queries using Supabase SQL Editor.
17. [SQL_Operations] Implement filtering using WHERE.
18. [SQL_Operations] Implement sorting using ORDER BY.
19. [SQL_Operations] Implement GROUP BY and HAVING.
20. [SQL_Operations] Use aggregate functions such as COUNT, SUM, AVG, MIN, and MAX.
21. [SQL_Operations] Implement SQL joins.
22. [SQL_Operations] Implement subqueries.
23. [SQL_Operations] Create and use database views.
24. [CRUD] Implement Create operations using Supabase Client.
25. [CRUD] Implement Read operations using Supabase Client.
26. [CRUD] Implement Update operations using Supabase Client.
27. [CRUD] Implement Delete operations using Supabase Client.
28. [CRUD] Create a Student Management CRUD application.
29. [CRUD] Create a Product Management CRUD application.
30. [CRUD] Create a User Management CRUD application.
31. [Authentication] Configure Supabase Authentication.
32. [Authentication] Implement user registration.
33. [Authentication] Implement user login.
34. [Authentication] Implement user logout.
35. [Authentication] Retrieve the currently authenticated user.
36. [Authentication] Implement email/password authentication.
37. [Authentication] Implement password reset.
38. [Authentication] Manage authentication sessions.
39. [Authentication] Implement protected pages/routes using Supabase Authentication.
40. [Security] Enable Row Level Security (RLS).
41. [Security] Create RLS policies.
42. [Security] Restrict users to their own records.
43. [Security] Create Admin and User roles.
44. [Security] Implement role-based access control.
45. [Security] Implement authenticated-user policies.
46. [Security] Test database access with different users.
47. [Storage] Create a Supabase Storage bucket.
48. [Storage] Upload files using Supabase Storage.
49. [Storage] Retrieve files from Storage.
50. [Storage] Download files from Storage.
51. [Storage] Delete files from Storage.
52. [Storage] Generate public file URLs.
53. [Storage] Implement image/file upload with authentication.
54. [Realtime] Enable Supabase Realtime.
55. [Realtime] Listen for database INSERT events.
56. [Realtime] Listen for database UPDATE events.
57. [Realtime] Listen for database DELETE events.
58. [Realtime] Create a realtime chat application.
59. [Realtime] Create a realtime student record application.
60. [Edge_Functions] Create a Supabase Edge Function.
61. [Edge_Functions] Deploy an Edge Function.
62. [Edge_Functions] Pass data to an Edge Function.
63. [Edge_Functions] Return JSON responses from an Edge Function.
64. [Edge_Functions] Implement authentication inside an Edge Function.
65. [Edge_Functions] Connect an Edge Function with a Supabase database.
66. [REST_API] Access Supabase tables through the generated REST API.
67. [REST_API] Implement GET operations using Supabase REST API.
68. [REST_API] Implement POST operations using Supabase REST API.
69. [REST_API] Implement PATCH/UPDATE operations using Supabase REST API.
70. [REST_API] Implement DELETE operations using Supabase REST API.
71. [REST_API] Implement API filtering and pagination.
72. [REST_API] Test Supabase REST APIs using Postman.
73. [Projects] Create a Student Management System using Supabase.
74. [Projects] Create a User Authentication System using Supabase.
75. [Projects] Create a Product Management System using Supabase.
76. [Projects] Create a Realtime Chat Application using Supabase.
77. [Projects] Create a File Upload Application using Supabase Storage.
78. [Projects] Create a Student REST API using Supabase.
79. [Projects] Create a Role-Based Admin Dashboard using Supabase Authentication and RLS.
