# HTML, CSS & JavaScript Practical Programs

## Student Details
- Student Name: ______________________________
- Register Number: ___________________________
- Class / Section: ____________________________
- Subject: HTML, CSS & JavaScript
- Assignment: Practical Programs Website

## Completion
Total number of separate HTML program files: **574**

Breakdown:
- HTML: 15
- CSS: 270
- JavaScript Core: 67
- DOM: 90
- Events: 30
- Forms & Validation: 40
- Browser & Features: 20
- Web Storage: 25
- Mini Projects: 17

## How to use
1. Open `index.html` in a browser.
2. Choose HTML, CSS, or JavaScript.
3. Open any program from its list.
4. Use the Home / Back to Programs links on each page.
5. The pages are self-contained and use the shared stylesheet in `assets/style.css`.

## Notes
- The program titles and organization are based on the uploaded experiments list.
- This ZIP covers the HTML/CSS/JavaScript portion of the assignment. The uploaded source also contains separate MySQL, Node.js and Supabase experiment lists, which are not included because this assignment request is for the HTML, CSS & JavaScript practical website.
- Some demonstrations that depend on browser permissions, remote media, or remote images may behave differently when offline.
- Replace the Student Details placeholders before submission.
